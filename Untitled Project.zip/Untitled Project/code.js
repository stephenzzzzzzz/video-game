var p5Inst = new p5(null, 'sketch');

window.preload = function () {
  initMobileControls(p5Inst);

  p5Inst._predefinedSpriteAnimations = {};
  p5Inst._pauseSpriteAnimationsByDefault = false;
  var animationListJSON = {"orderedKeys":["4bb6eaf7-d24c-447b-b849-3cad416744e8","a2f5590f-1683-4156-a235-5622abf75868","29dd9513-2d99-4f62-8daa-2b8b826ab684","4dd215f1-c34a-4b18-821a-56bf82ae1b4c"],"propsByKey":{"4bb6eaf7-d24c-447b-b849-3cad416744e8":{"name":"Cartoon Jay Kay","sourceUrl":null,"frameSize":{"x":190,"y":392},"frameCount":1,"looping":true,"frameDelay":12,"version":"He4oY_ICOLuzCrenQO5.Fph0vgpgg6g5","categories":["people"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":190,"y":392},"rootRelativePath":"assets/4bb6eaf7-d24c-447b-b849-3cad416744e8.png"},"a2f5590f-1683-4156-a235-5622abf75868":{"name":"Jay Kay","sourceUrl":null,"frameSize":{"x":150,"y":234},"frameCount":1,"looping":true,"frameDelay":12,"version":"wySfTpukLCimGtiGy83.Xqk6WgIPVrlN","categories":[""],"loadedFromSource":true,"saved":true,"sourceSize":{"x":150,"y":234},"rootRelativePath":"assets/a2f5590f-1683-4156-a235-5622abf75868.png"},"29dd9513-2d99-4f62-8daa-2b8b826ab684":{"name":"couch","sourceUrl":null,"frameSize":{"x":67,"y":25},"frameCount":1,"looping":true,"frameDelay":12,"version":"LKnIkfrp39IiPFVfRTmLg4Id5cARFZlQ","loadedFromSource":true,"saved":true,"sourceSize":{"x":67,"y":25},"rootRelativePath":"assets/29dd9513-2d99-4f62-8daa-2b8b826ab684.png"},"4dd215f1-c34a-4b18-821a-56bf82ae1b4c":{"name":"Screenshot 2023-06-12 3.22.33 PM.png_1","sourceUrl":null,"frameSize":{"x":470,"y":166},"frameCount":1,"looping":true,"frameDelay":12,"version":"ZvRcHuYNd5.CZBwMn.XCj9soqMx0rzi8","categories":[""],"loadedFromSource":true,"saved":true,"sourceSize":{"x":470,"y":166},"rootRelativePath":"assets/4dd215f1-c34a-4b18-821a-56bf82ae1b4c.png"}}};
  var orderedKeys = animationListJSON.orderedKeys;
  var allAnimationsSingleFrame = false;
  orderedKeys.forEach(function (key) {
    var props = animationListJSON.propsByKey[key];
    var frameCount = allAnimationsSingleFrame ? 1 : props.frameCount;
    var image = loadImage(props.rootRelativePath, function () {
      var spriteSheet = loadSpriteSheet(
          image,
          props.frameSize.x,
          props.frameSize.y,
          frameCount
      );
      p5Inst._predefinedSpriteAnimations[props.name] = loadAnimation(spriteSheet);
      p5Inst._predefinedSpriteAnimations[props.name].looping = props.looping;
      p5Inst._predefinedSpriteAnimations[props.name].frameDelay = props.frameDelay;
    });
  });

  function wrappedExportedCode(stage) {
    if (stage === 'preload') {
      if (setup !== window.setup) {
        window.setup = setup;
      } else {
        return;
      }
    }
// -----

World.frameRate = 15;
var jay = createSprite(200, 350);
jay.setAnimation("Jay Kay");
//our protagonist.
jay.x = 200;
jay.y = 350;
jay.width = 30;
jay.height = 100;
var couch = createSprite(0, 0);
//our antagonist, jay must avoid him
couch.setAnimation("couch");
couch.scale = 1.7;
couch.width = 70;
couch.height = 30;
var youwin = createSprite(200, 200);
youwin.setAnimation("Screenshot 2023-06-12 3.22.33 PM.png_1");
youwin.visible = false;
function draw() {
  //make the couch move
  couch.velocityX = 5;
  couch.velocityY = 5;
  //let the player control jay
  if (keyDown("right")) {
    jay.x = jay.x + 5;
  }
  if (keyDown("left")) {
    jay.x = jay.x - 5;
  }
  if (keyDown("up")) {
    jay.y = jay.y - 5;
  }
  if (keyDown("down")) {
    jay.y = jay.y + 5;
  }
  if (keyDown("space")) {
    jay.setAnimation("Cartoon Jay Kay");
  }
  //The couch will kill jay
  if (jay.isTouching(couch)) {
    jay.destroy();
    couch.destroy();
  }
  if (couch.y>400) {
    youwin.visible = true;
  }
  background("grey");
  //some decorative text 
  fill("white");
  textSize(20);
  text("look out jay kay!", 20, 20);
  drawSprites();
}

// -----
    try { window.draw = draw; } catch (e) {}
    switch (stage) {
      case 'preload':
        if (preload !== window.preload) { preload(); }
        break;
      case 'setup':
        if (setup !== window.setup) { setup(); }
        break;
    }
  }
  window.wrappedExportedCode = wrappedExportedCode;
  wrappedExportedCode('preload');
};

window.setup = function () {
  window.wrappedExportedCode('setup');
};
